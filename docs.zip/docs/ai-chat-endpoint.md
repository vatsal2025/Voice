# AI Chat Endpoint Documentation

## Overview

The `/api/ai/chat` endpoint provides general conversational AI capabilities, enabling open-ended queries beyond web-specific commands. This endpoint uses the AIClient to communicate with configured AI providers (Groq or OpenAI) and provides a flexible interface for various types of user interactions.

## Endpoint Details

- **URL**: `POST /api/ai/chat`
- **Content-Type**: `application/json`
- **Authentication**: None required
- **Rate Limiting**: Subject to server rate limits (default: 1000 requests per 15 minutes)

## Request Format

```json
{
  "message": "Your question or message here",
  "context": "Optional additional context for the AI",
  "options": {
    "provider": "auto",
    "model": "llama3-8b-8192",
    "temperature": 0.7,
    "maxTokens": 2000,
    "timeout": 30000,
    "sessionId": "optional-session-id"
  }
}
```

### Required Fields

- **message** (string): The user's message or question. Must be between 1 and 10,000 characters.

### Optional Fields

- **context** (string): Additional context to help the AI understand the request better
- **options** (object): Configuration options for AI generation
  - **provider** (string): `"auto"`, `"groq"`, or `"openai"`. Defaults to `"auto"`
  - **model** (string): Specific AI model to use (provider-dependent)
  - **temperature** (number): Creativity level (0.0-1.0). Higher values are more creative. Defaults to 0.7
  - **maxTokens** (number): Maximum response length. Defaults to 2000
  - **timeout** (number): Request timeout in milliseconds. Defaults to 30000
  - **sessionId** (string): Optional session identifier for tracking conversations

## Response Format

### Success Response (200 OK)

```json
{
  "success": true,
  "message": "Your original message",
  "response": "AI generated response",
  "metadata": {
    "processingTime": 1500,
    "provider": "groq",
    "model": "llama3-8b-8192",
    "requestId": "uuid-v4-string",
    "usage": {
      "promptTokens": 120,
      "completionTokens": 85,
      "totalTokens": 205
    },
    "usingFallback": false
  },
  "timestamp": "2025-08-10T12:30:45.123Z"
}
```

### Error Responses

#### 400 Bad Request - Missing/Invalid Data
```json
{
  "error": "Missing required field",
  "message": "Message field is required",
  "timestamp": "2025-08-10T12:30:45.123Z"
}
```

#### 503 Service Unavailable - AI Service Not Configured
```json
{
  "error": "AI service not configured",
  "message": "No AI providers are configured. Please check your GROQ_API_KEY or OPENAI_API_KEY configuration.",
  "timestamp": "2025-08-10T12:30:45.123Z",
  "availableProviders": []
}
```

#### 500 Internal Server Error - Generation Failed
```json
{
  "error": "Chat response generation failed",
  "message": "Detailed error message",
  "timestamp": "2025-08-10T12:30:45.123Z"
}
```

## Example Usage

### Basic Chat Request

```bash
curl -X POST http://localhost:3000/api/ai/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "What is the capital of France?"
  }'
```

### Chat with Context and Custom Options

```bash
curl -X POST http://localhost:3000/api/ai/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Can you explain this code snippet?",
    "context": "I am working on a JavaScript project and found this code: const arr = [1,2,3].map(x => x * 2);",
    "options": {
      "temperature": 0.3,
      "maxTokens": 1000,
      "provider": "groq"
    }
  }'
```

### JavaScript/Node.js Example

```javascript
const response = await fetch('http://localhost:3000/api/ai/chat', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    message: 'How do I implement a binary search algorithm?',
    options: {
      temperature: 0.2,
      maxTokens: 1500
    }
  })
});

const data = await response.json();
console.log('AI Response:', data.response);
```

## System Prompt

The endpoint uses a comprehensive system prompt that enables the AI to assist with:

- General knowledge and information
- Problem-solving and analysis
- Writing and editing assistance
- Programming and technical questions
- Creative tasks and brainstorming
- Explanations and tutorials
- Research and fact-checking

The AI is instructed to be conversational but professional, acknowledge uncertainty when appropriate, and provide well-structured responses.

## Provider Configuration

The endpoint requires at least one AI provider to be configured:

1. **Groq**: Set `GROQ_API_KEY` environment variable
2. **OpenAI**: Set `OPENAI_API_KEY` environment variable

The endpoint will automatically select the best available provider when `provider: "auto"` is used (default).

## Rate Limiting and Performance

- Default rate limit: 1000 requests per 15 minutes per IP
- Response time typically: 500ms - 3000ms depending on provider and complexity
- Automatic fallback between providers if one fails
- Request/response tracking for debugging

## Use Cases

This endpoint is ideal for:

1. **General Q&A**: Users can ask any question and get intelligent responses
2. **Code Help**: Programming questions, debugging, code explanations
3. **Creative Writing**: Story ideas, content generation, editing assistance
4. **Learning**: Explanations of complex topics, tutorials
5. **Problem Solving**: Analysis and solutions for various problems
6. **Research**: Quick facts, summaries, information gathering

## Integration with Voice Web System

While this endpoint provides general conversational AI, it complements the existing web-specific endpoints:

- `/api/ai/page-summary` - For summarizing web page content
- `/api/ai/page-qa` - For answering questions about specific web pages
- `/api/ai/chat` - For general conversation and open-ended queries

This allows the voice web interaction system to handle both web-specific tasks and general AI assistance seamlessly.
