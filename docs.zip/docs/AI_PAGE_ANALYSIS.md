# AI Page Analysis API

The AI Page Analysis service provides endpoints for summarizing and answering questions about web page content using advanced AI models (Groq/OpenAI).

## Features

- **HTML/Text Content Analysis**: Automatically detects and processes both HTML and plain text content
- **Intelligent Chunking**: Breaks large content into manageable pieces with smart overlap
- **Multi-Provider AI Support**: Uses Groq as primary provider with OpenAI fallback
- **Result Combination**: Automatically combines multi-chunk results into coherent responses
- **Configurable Options**: Adjustable chunk sizes, AI parameters, and processing options

## Endpoints

### 1. Page Summary - `POST /api/ai/page-summary`

Generates a comprehensive summary of web page content.

#### Request Body

```json
{
  "content": "string (required) - Raw HTML or plain text content",
  "url": "string (optional) - URL of the page for context", 
  "context": "string (optional) - Additional context or instructions",
  "options": {
    "maxChunkSize": 4000,
    "chunkOverlap": 200,
    "combineResults": true,
    "provider": "auto",
    "model": "string (optional)",
    "temperature": 0.3,
    "maxTokens": 1500,
    "timeout": 30000
  }
}
```

#### Example Request

```json
{
  "content": "<!DOCTYPE html><html><body><h1>Machine Learning Guide</h1><p>Machine learning is a subset of artificial intelligence...</p></body></html>",
  "url": "https://example.com/ml-guide",
  "context": "This is an educational article",
  "options": {
    "maxChunkSize": 3000,
    "temperature": 0.2
  }
}
```

#### Response

```json
{
  "success": true,
  "summary": "This article provides a comprehensive introduction to machine learning...",
  "metadata": {
    "processingTime": 2500,
    "chunksProcessed": 2,
    "combinedResults": true,
    "source": {
      "url": "https://example.com/ml-guide",
      "contentLength": 15420,
      "chunkSizes": [3000, 2420]
    },
    "aiProvider": {
      "provider": "groq",
      "model": "llama3-8b-8192",
      "totalTokens": 850,
      "responseTime": 2500
    }
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### 2. Page Q&A - `POST /api/ai/page-qa`

Answers specific questions about web page content.

#### Request Body

```json
{
  "content": "string (required) - Raw HTML or plain text content",
  "question": "string (required) - Question to ask about the content",
  "url": "string (optional) - URL of the page for context",
  "context": "string (optional) - Additional context or instructions", 
  "options": {
    "maxChunkSize": 4000,
    "chunkOverlap": 200,
    "combineResults": true,
    "provider": "auto",
    "model": "string (optional)",
    "temperature": 0.2,
    "maxTokens": 1500,
    "timeout": 30000
  }
}
```

#### Example Request

```json
{
  "content": "<!DOCTYPE html><html><body><h1>Product Pricing</h1><p>Our basic plan costs $29/month...</p></body></html>",
  "question": "What are the different pricing plans available?",
  "url": "https://example.com/pricing",
  "options": {
    "temperature": 0.1
  }
}
```

#### Response

```json
{
  "success": true,
  "question": "What are the different pricing plans available?",
  "answer": "Based on the content, there are three pricing plans available: Basic ($29/month), Pro ($59/month), and Enterprise ($99/month). Each plan includes different features...",
  "metadata": {
    "processingTime": 1800,
    "chunksProcessed": 1,
    "combinedResults": false,
    "source": {
      "url": "https://example.com/pricing",
      "contentLength": 2500,
      "chunkSizes": [2500]
    },
    "aiProvider": {
      "provider": "groq", 
      "model": "llama3-8b-8192",
      "totalTokens": 420,
      "responseTime": 1800
    }
  },
  "timestamp": "2024-01-15T10:32:00.000Z"
}
```

### 3. Service Status - `GET /api/ai/status`

Get the current status and configuration of the AI service.

#### Response

```json
{
  "success": true,
  "status": {
    "configured": true,
    "availableProviders": ["groq", "openai"],
    "features": {
      "pageSummary": true,
      "pageQA": true,
      "chunking": true,
      "htmlExtraction": true
    }
  },
  "endpoints": [
    "POST /api/ai/page-summary - Summarize web page content",
    "POST /api/ai/page-qa - Answer questions about web page content",
    "GET /api/ai/status - Get service status"
  ],
  "timestamp": "2024-01-15T10:35:00.000Z"
}
```

## Configuration Options

### Content Processing
- **maxChunkSize**: Maximum size of content chunks (default: 4000 characters)
- **chunkOverlap**: Overlap between chunks to maintain context (default: 200 characters)  
- **combineResults**: Whether to combine multi-chunk results (default: true)

### AI Parameters
- **provider**: AI provider to use ('auto', 'groq', 'openai') (default: 'auto')
- **model**: Specific model to use (uses provider default if not specified)
- **temperature**: Creativity/randomness (0.0-1.0) (default: 0.3 for summary, 0.2 for Q&A)
- **maxTokens**: Maximum tokens to generate (default: 1500)
- **timeout**: Request timeout in milliseconds (default: 30000)

## Error Handling

### Common Error Responses

#### 400 Bad Request - Missing Content
```json
{
  "error": "Missing required field",
  "message": "Content field is required",
  "timestamp": "2024-01-15T10:40:00.000Z"
}
```

#### 400 Bad Request - Content Too Large
```json
{
  "error": "Content too large",
  "message": "Content must be less than 500KB",
  "timestamp": "2024-01-15T10:41:00.000Z"
}
```

#### 503 Service Unavailable - AI Not Configured
```json
{
  "error": "AI service not configured",
  "message": "No AI providers are configured. Please check your GROQ_API_KEY or OPENAI_API_KEY configuration.",
  "timestamp": "2024-01-15T10:42:00.000Z",
  "availableProviders": []
}
```

#### 500 Internal Server Error - AI Processing Failed
```json
{
  "error": "Summary generation failed",
  "message": "Both Groq and OpenAI failed: API rate limit exceeded",
  "timestamp": "2024-01-15T10:43:00.000Z"
}
```

## Usage Examples

### Basic Summary
```bash
curl -X POST http://localhost:3000/api/ai/page-summary \
  -H "Content-Type: application/json" \
  -d '{
    "content": "Your HTML or text content here"
  }'
```

### Advanced Q&A with Custom Options
```bash
curl -X POST http://localhost:3000/api/ai/page-qa \
  -H "Content-Type: application/json" \
  -d '{
    "content": "Your content here",
    "question": "What is the main topic?",
    "url": "https://example.com",
    "options": {
      "provider": "groq",
      "temperature": 0.1,
      "maxChunkSize": 3000
    }
  }'
```

## Implementation Details

### Content Processing Pipeline
1. **HTML Detection**: Automatically detects HTML vs plain text
2. **Text Extraction**: Removes HTML tags and scripts while preserving content
3. **Text Chunking**: Intelligently splits text at sentence/paragraph boundaries
4. **AI Processing**: Processes each chunk with appropriate system prompts
5. **Result Combination**: Merges chunk results into coherent final response

### AI Provider Fallback
- Primary: Groq (fast, cost-effective)
- Fallback: OpenAI (when Groq fails or unavailable)
- Auto-selection based on availability and configuration

### System Prompts
- **Summary**: Optimized for creating comprehensive, structured summaries
- **Q&A**: Optimized for accurate, direct answers based on content
- **Combination**: Optimized for merging multiple analysis results

## Performance Considerations

- **Content Size**: 500KB limit per request
- **Chunking**: Automatic chunking for large content (4000 chars/chunk by default)
- **Rate Limiting**: Subject to server-wide rate limits
- **Caching**: Service instances are cached for performance
- **Timeouts**: Configurable timeouts with 30-second default

## Security & Privacy

- Content is processed in memory only (not stored)
- API keys are securely managed through environment variables
- Request/response logging respects privacy settings
- Rate limiting prevents abuse
